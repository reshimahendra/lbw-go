--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "lbw-go";
--
-- Name: lbw-go; Type: DATABASE; Schema: -; Owner: lotus
--

CREATE DATABASE "lbw-go" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE "lbw-go" OWNER TO lotus;

\connect -reuse-previous=on "dbname='lbw-go'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: getconfigid(uuid); Type: FUNCTION; Schema: public; Owner: lotus
--

CREATE FUNCTION public.getconfigid(id uuid) RETURNS integer
    LANGUAGE sql
    AS $$
select coalesce(max(cfg_id), 0)+1 as cfgID 
from membership_mail_app_config 
where  id = id;
$$;


ALTER FUNCTION public.getconfigid(id uuid) OWNER TO lotus;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: membership_mail_app; Type: TABLE; Schema: public; Owner: lotus
--

CREATE TABLE public.membership_mail_app (
    id uuid NOT NULL,
    type_id smallint DEFAULT 0 NOT NULL,
    status_id smallint DEFAULT 0 NOT NULL,
    price money DEFAULT 0 NOT NULL,
    last_paid_amount money DEFAULT 0 NOT NULL,
    last_paid_at timestamp without time zone,
    subscribed_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.membership_mail_app OWNER TO lotus;

--
-- Name: TABLE membership_mail_app; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON TABLE public.membership_mail_app IS 'user membership to mail app service for mail service handler on static site';


--
-- Name: COLUMN membership_mail_app.type_id; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.membership_mail_app.type_id IS 'refer to membership mail app type';


--
-- Name: COLUMN membership_mail_app.status_id; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.membership_mail_app.status_id IS 'refer to membership status';


--
-- Name: COLUMN membership_mail_app.price; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.membership_mail_app.price IS 'membership subscription price';


--
-- Name: membership_mail_app_config; Type: TABLE; Schema: public; Owner: lotus
--

CREATE TABLE public.membership_mail_app_config (
    cfg_id smallint NOT NULL,
    id uuid NOT NULL,
    config_name character varying(30) NOT NULL,
    default_config boolean DEFAULT false NOT NULL,
    smtp_server character varying(100) NOT NULL,
    smtp_port integer NOT NULL,
    smtp_username character varying(75) NOT NULL,
    smtp_password character varying(50) NOT NULL,
    smtp_sender_email character varying(75) NOT NULL,
    smtp_sender_identity character varying(50) NOT NULL,
    active_status boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.membership_mail_app_config OWNER TO lotus;

--
-- Name: TABLE membership_mail_app_config; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON TABLE public.membership_mail_app_config IS 'user configuration for their mail server configuration';


--
-- Name: COLUMN membership_mail_app_config.default_config; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.membership_mail_app_config.default_config IS 'whether this config is default config or not';


--
-- Name: COLUMN membership_mail_app_config.deleted_at; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.membership_mail_app_config.deleted_at IS 'soft delete features';


--
-- Name: membership_mail_app_type; Type: TABLE; Schema: public; Owner: lotus
--

CREATE TABLE public.membership_mail_app_type (
    id smallint NOT NULL,
    type_name character varying(50) NOT NULL,
    description text,
    price money DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.membership_mail_app_type OWNER TO lotus;

--
-- Name: TABLE membership_mail_app_type; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON TABLE public.membership_mail_app_type IS 'Membership of mail app service';


--
-- Name: COLUMN membership_mail_app_type.type_name; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.membership_mail_app_type.type_name IS 'Membership type name';


--
-- Name: COLUMN membership_mail_app_type.description; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.membership_mail_app_type.description IS 'description for the membership service';


--
-- Name: COLUMN membership_mail_app_type.price; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.membership_mail_app_type.price IS 'price of the service';


--
-- Name: COLUMN membership_mail_app_type.created_at; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.membership_mail_app_type.created_at IS 'date time the membership created';


--
-- Name: COLUMN membership_mail_app_type.updated_at; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.membership_mail_app_type.updated_at IS 'datetime the membershipservice was updated';


--
-- Name: COLUMN membership_mail_app_type.deleted_at; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.membership_mail_app_type.deleted_at IS 'soft delete for the membership status';


--
-- Name: membership_status; Type: TABLE; Schema: public; Owner: lotus
--

CREATE TABLE public.membership_status (
    id smallint NOT NULL,
    status_name character varying(30) NOT NULL,
    description text
);


ALTER TABLE public.membership_status OWNER TO lotus;

--
-- Name: TABLE membership_status; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON TABLE public.membership_status IS 'membership status';


--
-- Name: COLUMN membership_status.id; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.membership_status.id IS 'membership id will refer to user id. using 1:1 relation';


--
-- Name: user_role_id_seq; Type: SEQUENCE; Schema: public; Owner: lotus
--

CREATE SEQUENCE public.user_role_id_seq
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_role_id_seq OWNER TO lotus;

--
-- Name: user_role; Type: TABLE; Schema: public; Owner: lotus
--

CREATE TABLE public.user_role (
    id smallint DEFAULT nextval('public.user_role_id_seq'::regclass) NOT NULL,
    role_name character varying(30) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.user_role OWNER TO lotus;

--
-- Name: TABLE user_role; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON TABLE public.user_role IS 'user role containing role hold by the user';


--
-- Name: user_status; Type: TABLE; Schema: public; Owner: lotus
--

CREATE TABLE public.user_status (
    id smallint NOT NULL,
    status_name character varying NOT NULL,
    description text
);


ALTER TABLE public.user_status OWNER TO lotus;

--
-- Name: TABLE user_status; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON TABLE public.user_status IS 'user account status';


--
-- Name: users; Type: TABLE; Schema: public; Owner: lotus
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    username character varying(30) NOT NULL,
    firstname character varying(30) NOT NULL,
    lastname character varying(30),
    email character varying(100) NOT NULL,
    passkey character varying(100) NOT NULL,
    status_id smallint DEFAULT 0 NOT NULL,
    role_id smallint DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone,
    activated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO lotus;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON TABLE public.users IS 'User table';


--
-- Name: COLUMN users.status_id; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.users.status_id IS 'user status';


--
-- Name: COLUMN users.role_id; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.users.role_id IS 'user role on system';


--
-- Name: COLUMN users.activated_at; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.users.activated_at IS 'account activation datetime';


--
-- Name: COLUMN users.deleted_at; Type: COMMENT; Schema: public; Owner: lotus
--

COMMENT ON COLUMN public.users.deleted_at IS 'account (soft) delete datetime';


--
-- Data for Name: membership_mail_app; Type: TABLE DATA; Schema: public; Owner: lotus
--

COPY public.membership_mail_app (id, type_id, status_id, price, last_paid_amount, last_paid_at, subscribed_at, updated_at) FROM stdin;
\.
COPY public.membership_mail_app (id, type_id, status_id, price, last_paid_amount, last_paid_at, subscribed_at, updated_at) FROM '$$PATH$$/3068.dat';

--
-- Data for Name: membership_mail_app_config; Type: TABLE DATA; Schema: public; Owner: lotus
--

COPY public.membership_mail_app_config (cfg_id, id, config_name, default_config, smtp_server, smtp_port, smtp_username, smtp_password, smtp_sender_email, smtp_sender_identity, active_status, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.membership_mail_app_config (cfg_id, id, config_name, default_config, smtp_server, smtp_port, smtp_username, smtp_password, smtp_sender_email, smtp_sender_identity, active_status, created_at, updated_at, deleted_at) FROM '$$PATH$$/3066.dat';

--
-- Data for Name: membership_mail_app_type; Type: TABLE DATA; Schema: public; Owner: lotus
--

COPY public.membership_mail_app_type (id, type_name, description, price, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.membership_mail_app_type (id, type_name, description, price, created_at, updated_at, deleted_at) FROM '$$PATH$$/3061.dat';

--
-- Data for Name: membership_status; Type: TABLE DATA; Schema: public; Owner: lotus
--

COPY public.membership_status (id, status_name, description) FROM stdin;
\.
COPY public.membership_status (id, status_name, description) FROM '$$PATH$$/3065.dat';

--
-- Data for Name: user_role; Type: TABLE DATA; Schema: public; Owner: lotus
--

COPY public.user_role (id, role_name, description, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.user_role (id, role_name, description, created_at, updated_at, deleted_at) FROM '$$PATH$$/3063.dat';

--
-- Data for Name: user_status; Type: TABLE DATA; Schema: public; Owner: lotus
--

COPY public.user_status (id, status_name, description) FROM stdin;
\.
COPY public.user_status (id, status_name, description) FROM '$$PATH$$/3062.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: lotus
--

COPY public.users (id, username, firstname, lastname, email, passkey, status_id, role_id, created_at, updated_at, activated_at, deleted_at) FROM stdin;
\.
COPY public.users (id, username, firstname, lastname, email, passkey, status_id, role_id, created_at, updated_at, activated_at, deleted_at) FROM '$$PATH$$/3064.dat';

--
-- Name: user_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lotus
--

SELECT pg_catalog.setval('public.user_role_id_seq', 10, true);


--
-- Name: membership_mail_app_config membership_mail_app_config_name_un; Type: CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.membership_mail_app_config
    ADD CONSTRAINT membership_mail_app_config_name_un UNIQUE (config_name);


--
-- Name: membership_mail_app_config membership_mail_app_config_pk; Type: CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.membership_mail_app_config
    ADD CONSTRAINT membership_mail_app_config_pk PRIMARY KEY (cfg_id, id);


--
-- Name: membership_mail_app membership_mail_app_pk; Type: CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.membership_mail_app
    ADD CONSTRAINT membership_mail_app_pk PRIMARY KEY (id);


--
-- Name: membership_mail_app_type membership_mail_app_type_name_un; Type: CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.membership_mail_app_type
    ADD CONSTRAINT membership_mail_app_type_name_un UNIQUE (type_name);


--
-- Name: membership_mail_app_type membership_mail_app_type_pk; Type: CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.membership_mail_app_type
    ADD CONSTRAINT membership_mail_app_type_pk PRIMARY KEY (id);


--
-- Name: membership_status membership_status_name_un; Type: CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.membership_status
    ADD CONSTRAINT membership_status_name_un UNIQUE (status_name);


--
-- Name: membership_status membership_status_pk; Type: CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.membership_status
    ADD CONSTRAINT membership_status_pk PRIMARY KEY (id);


--
-- Name: user_role user_role_name_un; Type: CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT user_role_name_un UNIQUE (role_name);


--
-- Name: user_role user_role_pk; Type: CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT user_role_pk PRIMARY KEY (id);


--
-- Name: user_status user_status_name_un; Type: CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.user_status
    ADD CONSTRAINT user_status_name_un UNIQUE (status_name);


--
-- Name: user_status user_status_pk; Type: CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.user_status
    ADD CONSTRAINT user_status_pk PRIMARY KEY (id);


--
-- Name: users users_email_un; Type: CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_un UNIQUE (email);


--
-- Name: users users_pk; Type: CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pk PRIMARY KEY (id);


--
-- Name: users users_username_un; Type: CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_un UNIQUE (username);


--
-- Name: membership_mail_app_config membership_mail_app_config_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.membership_mail_app_config
    ADD CONSTRAINT membership_mail_app_config_users_fk FOREIGN KEY (id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: membership_mail_app membership_mail_app_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.membership_mail_app
    ADD CONSTRAINT membership_mail_app_status_fk FOREIGN KEY (status_id) REFERENCES public.membership_status(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: membership_mail_app membership_mail_app_type_fk; Type: FK CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.membership_mail_app
    ADD CONSTRAINT membership_mail_app_type_fk FOREIGN KEY (type_id) REFERENCES public.membership_mail_app_type(id) ON UPDATE CASCADE;


--
-- Name: membership_mail_app membership_mail_app_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.membership_mail_app
    ADD CONSTRAINT membership_mail_app_user_fk FOREIGN KEY (id) REFERENCES public.users(id) ON UPDATE CASCADE;


--
-- Name: users users_user_role_fk; Type: FK CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_user_role_fk FOREIGN KEY (role_id) REFERENCES public.user_role(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_user_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: lotus
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_user_status_fk FOREIGN KEY (status_id) REFERENCES public.user_status(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

